package com.android.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class SIGNIN extends AppCompatActivity {

    EditText editUserName, editPassword;
    Button signinButton, homeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signin);

        editUserName = findViewById(R.id.et_username);
        editPassword = findViewById(R.id.et_password);
        signinButton = findViewById(R.id.bt_signin1);
        homeButton = findViewById(R.id.bt_home);

        signinButton.setOnClickListener(v -> {
            String username = editUserName.getText().toString();
            String password = editPassword.getText().toString();
            if (username.isEmpty()) {
                Toast.makeText(this, "Enter UserName", Toast.LENGTH_LONG).show();
            } else if (password.isEmpty()) {
                Toast.makeText(this, "Enter Password", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Login Successful " + username, Toast.LENGTH_LONG).show();
            }
        });

        homeButton.setOnClickListener(v -> {
            Intent homeintent = new Intent(SIGNIN.this, MainActivity.class);
            startActivity(homeintent);
        });
    }
}