package com.android.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button signinButton, signupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        signinButton = findViewById(R.id.bt_signin);
        signupButton = findViewById(R.id.bt_signup);

        signinButton.setOnClickListener(v -> {
            Intent signinintent = new Intent(MainActivity.this, SIGNIN.class);
            startActivity(signinintent);
        });

        signupButton.setOnClickListener(v -> {
            Intent signupintent = new Intent(MainActivity.this, SIGNUP.class);
            startActivity(signupintent);
        });
    }
}