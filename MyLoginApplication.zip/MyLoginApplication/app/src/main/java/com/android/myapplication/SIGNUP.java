package com.android.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class SIGNUP extends AppCompatActivity {

    EditText editFirstName, editLastName, editMobileNumber, editAddress, editSetPassword, editCNFPassword, editemail;
    Button signupButton, homeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);

        editFirstName = findViewById(R.id.et_firstname);
        editLastName = findViewById(R.id.et_lastname);
        editMobileNumber = findViewById(R.id.et_phnumber);
        editAddress = findViewById(R.id.et_address);
        editSetPassword = findViewById(R.id.et_setpassword);
        editCNFPassword = findViewById(R.id.et_cnfpassword);
        editemail = findViewById(R.id.et_email);
        signupButton = findViewById(R.id.bt_signup1);
        homeButton = findViewById(R.id.bt_home);

        signupButton.setOnClickListener(v -> {
            String firstname = editFirstName.getText().toString();
            String mobilenumber = editMobileNumber.getText().toString();
            String address = editAddress.getText().toString();
            String setpassword = editSetPassword.getText().toString();
            String cnfpassword = editCNFPassword.getText().toString();
            String lastname = editLastName.getText().toString();
            String email = editemail.getText().toString();

            boolean mailvalid = Patterns.EMAIL_ADDRESS.matcher(email).matches();
            if (firstname.isEmpty()) {
                Toast.makeText(this, "Enter FirstName", Toast.LENGTH_LONG).show();
            } else if (mobilenumber.isEmpty()) {
                Toast.makeText(this, "Enter Ph.Number", Toast.LENGTH_LONG).show();
            } else if (email.isEmpty()) {
                Toast.makeText(this, "Enter E-Mail", Toast.LENGTH_LONG).show();
            } else if (address.isEmpty()) {
                Toast.makeText(this, "Enter Address", Toast.LENGTH_LONG).show();
            } else if (setpassword.isEmpty()) {
                Toast.makeText(this, "Enter Password", Toast.LENGTH_LONG).show();
            } else if (cnfpassword.isEmpty()) {
                Toast.makeText(this, "Enter Confirm Password", Toast.LENGTH_LONG).show();
            } else if (!mobilenumber.matches("[0-9]{10}")) {
                Toast.makeText(this, "Invalid Ph.Number", Toast.LENGTH_LONG).show();
            } else if (!mailvalid) {
                Toast.makeText(this, "Invalid E-Mail", Toast.LENGTH_SHORT).show();
            } else if (!cnfpassword.equals(setpassword)) {
                Toast.makeText(this, "Confirm Password must be same as the New Password", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Mr./Ms." + firstname + " " + lastname + " You have Successfully Registered in YummyFoods!", Toast.LENGTH_LONG).show();
            }
        });

        homeButton.setOnClickListener(v -> {
            Intent homeintent = new Intent(SIGNUP.this, MainActivity.class);
            startActivity(homeintent);
        });

    }
}